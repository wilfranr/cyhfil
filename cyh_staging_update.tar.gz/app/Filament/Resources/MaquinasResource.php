<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MaquinasResource\Pages;
use App\Filament\Resources\MaquinasResource\Pages\EditMaquinas;
use App\Filament\Resources\MaquinasResource\RelationManagers;
use App\Filament\Resources\MaquinaResource\RelationManagers\ReferenciasVendidasRelationManager;
use App\Models\Maquina;
use Filament\Forms;
use Filament\Forms\Components\Select;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use App\Filament\Resources\MaquinasResource\RelationManagers\MarcaRelationManager;
use App\Models\Fabricante;
use App\Models\Lista;
use App\Models\Tercero;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\TextInput;
use Filament\Tables\Filters\SelectFilter;
use Filament\Infolists\Infolist;
use Filament\Infolists\Components;
use Filament\Forms\Components\Section;

class MaquinasResource extends Resource
{
    protected static ?string $model = Maquina::class;

    protected static ?string $navigationIcon = 'heroicon-m-cog';

    protected static ?int $navigationSort = 6;

    protected static ?string $recordTitleAttribute = 'modelo';

    public static function getGloballySearchableAttributes(): array
    {
        return [
            'modelo',
            'serie',
            'arreglo',
            'fabricantes.nombre',
        ];
    }

    public static function getGlobalSearchResultDetails($record): array
    {
        return [
            'Tipo' => $tipo = Lista::query()->where('id', $record->tipo)->pluck('nombre')->first(),
            'Fabricante' => $record->fabricantes->nombre,
            'Modelo' => $record->modelo,
            'Serie' => $record->serie,
            'Arreglo' => $record->arreglo,
        ];
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make([

                    Select::make('tipo')
                        ->relationship('Listas', 'nombre')
                        ->createOptionForm(function () {
                            return [
                                Hidden::make('tipo')
                                    ->default('Tipo de Máquina')
                                    ->required()
                                    ->hidden(),
                                TextInput::make('nombre')
                                    ->label('Nombre')
                                    ->required()
                                    ->placeholder('Ingrese el nombre del tipo de máquina'),
                                MarkdownEditor::make('definicion')
                                    ->label('Descripción')
                                    ->required()
                                    ->placeholder('Proporcione una descripción del tipo de máquina'),
                                FileUpload::make('foto')
                                    ->label('Foto')
                                    ->image()
                            ];
                        })
                        ->createOptionUsing(function ($data) {
                            $tipo = Lista::create([
                                'nombre' => $data['nombre'],
                                'definicion' => $data['definicion'],
                                'tipo' => 'Tipo de Máquina',
                            ]);

                            return $tipo->id;
                        })
                        ->createOptionAction(function ($action) {
                            $action->modalHeading('Crear Tipo de Máquina');
                            $action->modalDescription('Crea un nuevo tipo de máquina y será asociado a la máquina automáticamente');
                            $action->modalWidth('lg');
                        })
                        ->editOptionForm([
                            Hidden::make('tipo')
                                ->default('Tipo de Máquina')
                                ->hidden(),
                            TextInput::make('nombre')
                                ->label('Nombre')
                                ->required()
                                ->placeholder('Ingrese el nombre del tipo de máquina'),
                            MarkdownEditor::make('definicion')
                                ->label('Descripción')
                                ->required()
                                ->placeholder('Proporcione una descripción del tipo de máquina'),
                            FileUpload::make('foto')
                                ->label('Foto')
                                ->image(),
                        ])
                        ->label('Tipo')
                        ->live()
                        ->preload()
                        ->searchable()
                        ->required()
                        ->hintIcon('heroicon-o-question-mark-circle', tooltip: function ($get) {
                            $tipo = $get('tipo'); // Obtiene el ID del tipo de máquina seleccionado
                            $definicion = Lista::where('id', $tipo)->value('definicion'); // Obtiene la definición desde la base de datos
                            return $definicion ?? 'Sin definición disponible';
                        })
                        ->hintColor('primary'),

                    Select::make('fabricante_id')
                        ->relationship('fabricantes', 'nombre')
                        ->label('Fabricante')
                        ->preload()
                        ->live()
                        ->searchable()
                        ->createOptionForm(function () {
                            return [
                                TextInput::make('nombre')
                                    ->label('Nombre')
                                    ->required()
                                    ->placeholder('Nombre del fabricante'),
                                MarkdownEditor::make('descripcion')
                                    ->label('Descripción')
                                    ->nullable()
                                    ->dehydrateStateUsing(fn(string $state): string => ucwords($state))
                                    ->required()
                                    ->maxLength(500),
                                FileUpload::make('logo')
                                    ->label('Logo')
                                    ->image(),
                            ];
                        })
                        ->editOptionForm([
                            TextInput::make('nombre')
                                ->label('Nombre')
                                ->required()
                                ->placeholder('Nombre del fabricante'),
                            MarkdownEditor::make('descripcion')
                                ->label('Descripción')
                                ->nullable()
                                ->dehydrateStateUsing(fn(string $state): string => ucwords($state))
                                ->required()
                                ->maxLength(500),
                            FileUpload::make('logo')
                                ->label('Logo')
                                ->image(),
                        ])
                        ->createOptionUsing(function ($data) {
                            $fabricante = Fabricante::create([
                                'nombre' => $data['nombre'],
                                'descripcion' => $data['descripcion'],
                                'logo' => $data['logo'],

                            ]);

                            return $fabricante->id;
                        })
                        ->createOptionAction(function ($action) {
                            $action->modalHeading('Crear Fabricante');
                            $action->modalDescription('Crea un nuevo fabricante y será asociado a la máquina automáticamente');
                            $action->modalWidth('lg');
                        }),

                    Forms\Components\TextInput::make('modelo')
                        ->label('Modelo')
                        ->required(),

                    TextInput::make('serie')
                        ->label('Serie')
                        ->unique(ignoreRecord: true),

                    TextInput::make('arreglo')
                        ->label('Arreglo'),
                        
                    Select::make('tercero_id')
                        ->relationship('terceros', 'nombre', function ($query) {
                            return $query->where('tipo','!=', 'Proveedor');
                        })
                        ->label('Propietario')
                        ->preload()
                        ->live()
                        ->searchable()
                        ->required()
                ])->columns(3),

                Section::make([
                    Forms\Components\FileUpload::make('foto')
                        ->label('Foto')
                        ->image()
                        ->imageEditor()
                        ->openable(),

                    Forms\Components\FileUpload::make('fotoId')
                        ->label('FotoId')
                        ->image()
                        ->imageEditor()
                        ->openable(),
                ])->columns(2),
            ]);
    }



    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')
                    ->label('ID')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\ImageColumn::make('foto')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('listas.nombre')
                    ->label('Tipo')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('fabricantes.nombre')
                    ->label('Fabricante')
                    ->searchable()
                    ->sortable(),


                Tables\Columns\TextColumn::make('modelo')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('serie')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('arreglo')
                    ->searchable()
                    ->sortable(),
            ])
            ->filters([])
            ->actions([
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->schema([
                Components\Group::make([
                    Components\Section::make()
                        ->schema([
                            Components\Group::make([
                                Components\TextEntry::make('listas.nombre')
                                    ->label('Tipo de Máquina'),
                                Components\TextEntry::make('fabricantes.nombre')
                                    ->label('Fabricante'),
                                Components\TextEntry::make('modelo')
                                    ->label('Modelo'),
                            ])->columns(3),
                            Components\Group::make([
                                Components\TextEntry::make('serie')
                                    ->label('Serie'),
                                Components\TextEntry::make('arreglo')
                                    ->label('Arreglo'),
                                Components\TextEntry::make('terceros.nombre')
                                    ->label('Propietario')
                                    ->visible(fn($record) => !empty($record->terceros)),

                            ])->columns(3),
                        ]),
                ]),
                Components\Group::make([
                    Components\Section::make('Fotos')
                        ->schema([
                            Components\ImageEntry::make('foto')
                                ->label('Foto')
                                ->width(200)
                                ->height(200)
                                ->visible(fn($record) => !empty($record->foto)),
                            Components\ImageEntry::make('fotoId')
                                ->label('Foto ID')
                                ->width(200)
                                ->height(200)
                                ->visible(fn($record) => !empty($record->fotoId)),
                        ])->columns(2),
                ]),

            ]);
    }

    public static function getRelations(): array
    {
        return [
            // 'terceros' => RelationManagers\TercerosRelationManager::class,
            'pedidos' => RelationManagers\PedidosRelationManager::class,
            'referenciasVendidas' => RelationManagers\ReferenciasVendidasRelationManager::class,
            
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListMaquinas::route('/'),
            'create' => Pages\CreateMaquinas::route('/create'),
            'edit' => Pages\EditMaquinas::route('/{record}/edit'),
            'view' => Pages\ViewMaquinas::route('/{record}'),
        ];
    }
}