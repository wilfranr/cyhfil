<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class WorldTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->call('Altwaireb\World\Database\Seeders\BaseWorldSeeder');
    }
}
