
<x-filament::button
    href="{{ route('downloadExcel') }}"
    tag="a"
    icon="heroicon-o-arrow-down-tray"
    label="Descargar plantilla"
    size="sm"
    >
Descargar plantilla
</x-filament::button>
