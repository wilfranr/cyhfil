<?php

namespace App\Livewire;

use Livewire\Component;

class ChatModal extends Component
{
    public function render()
    {
        return view('livewire.chat-modal');
    }
}
