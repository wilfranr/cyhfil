<?php

namespace App\Livewire;

use Livewire\Component;

class VerArticulo extends Component
{
    public function render()
    {
        return view('livewire.ver-articulo');
    }
}
