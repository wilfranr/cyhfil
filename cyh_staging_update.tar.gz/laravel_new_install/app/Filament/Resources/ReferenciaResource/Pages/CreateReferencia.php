<?php

namespace App\Filament\Resources\ReferenciaResource\Pages;

use App\Filament\Resources\ReferenciaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateReferencia extends CreateRecord
{
    protected static string $resource = ReferenciaResource::class;
}
