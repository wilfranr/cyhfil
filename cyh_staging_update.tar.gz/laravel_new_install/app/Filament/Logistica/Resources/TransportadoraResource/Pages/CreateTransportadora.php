<?php

namespace App\Filament\Logistica\Resources\TransportadoraResource\Pages;

use App\Filament\Logistica\Resources\TransportadoraResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTransportadora extends CreateRecord
{
    protected static string $resource = TransportadoraResource::class;
}
