<?php

namespace App\Filament\Logistica\Resources\PedidoResource\Pages;

use App\Filament\Logistica\Resources\PedidoResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePedido extends CreateRecord
{
    protected static string $resource = PedidoResource::class;
}
