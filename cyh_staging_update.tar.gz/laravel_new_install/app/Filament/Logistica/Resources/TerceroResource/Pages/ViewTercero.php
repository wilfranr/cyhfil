<?php

namespace App\Filament\Logistica\Resources\TerceroResource\Pages;

use App\Filament\Logistica\Resources\TerceroResource;
use Filament\Resources\Pages\ViewRecord;

class ViewTercero extends ViewRecord
{
    protected static string $resource = TerceroResource::class;
}
