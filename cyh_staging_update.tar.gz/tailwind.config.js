module.exports = {
    content: [
        "./resources/**/*.blade.php",
        "./vendor/filament/**/*.blade.php",
        "./vendor/awcodes/filament-table-repeater/resources/**/*.blade.php", // añade esta línea
    ],
    theme: {
        extend: {},
    },
    plugins: [],
};
